Backup time: 2026-05-23 at 10:23:35 UTC
ServerName: fastos-private
Current server version:41.78
Current world version:195
World version in this backup is:World isn't exist